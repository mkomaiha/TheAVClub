import React, {Component} from 'react';
import './Home.css';


class Home extends Component {
  render() {
    return (
      <div className="row" id="Body">
        <div className="medium-12 columns">
          <h2>Home</h2>
        </div>
      </div>
    );
  }
}
export default Home;
